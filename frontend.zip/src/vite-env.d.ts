/// <reference types="vite/client" />

clientId = "943334931075-2l9vk7lla6vo30nrqls49oldjll94v3d.apps.googleusercontent.com"
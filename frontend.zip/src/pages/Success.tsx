import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext'; // Adjust import path as needed

export default function Success() {
  const location = useLocation();
  const navigate = useNavigate();
  const { login } = useAuth(); // Get login function from AuthContext

  useEffect(() => {
    const query = new URLSearchParams(location.search);
    const token = query.get("token");

    if (token) {
      // Store the token in local storage and update AuthContext
      localStorage.setItem("googleToken", token);
      login(token);

      // Redirect to the home page
      navigate("/");
    }
  }, [location, login, navigate]);

  return (
    <div>Success</div>
  );
}

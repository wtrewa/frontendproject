import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from '../context/AuthContext'; // Adjust import path as needed


const AddPasswordPage: React.FC = () => {
  const [serviceName, setServiceName] = useState("");
  const [password, setPassword] = useState("");
  const [url, setUrl] = useState("");
  const navigate = useNavigate();
  const { token ,logout} = useAuth(); // Use the custom hook to get auth token

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
     const res =  await axios.post(
        "http://localhost:8080/api/password",
        {  password, url },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
      console.log(res)
      // Redirect to home page after successful submission
      navigate("/");
    } catch (error) {
      console.error("Error adding password", error);
    }
  };


  const handleLogout = () => {
    logout();
    navigate("/login");
  };
  

  return (
    <div className="add-password-container">
          <header className="home-header">
        <div className="profile-container">
          <img src="/path-to-profile-pic.jpg" alt="Profile" className="profile-pic" />
          <button onClick={handleLogout} className="logout-button">Logout</button>
        </div>
        <div className="nav-links">
          <Link to="/" className="add-password-link">Home</Link>
        </div>
      </header>
      <h1>Add a New Password</h1>
      <form onSubmit={handleSubmit} className="add-password-form">
        <div className="form-group">
          <label htmlFor="url">URL</label>
          <input
            type="url"
            id="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="submit-button">Add Password</button>
      </form>
    </div>
  );
};

export default AddPasswordPage;

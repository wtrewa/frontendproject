import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from '../context/AuthContext'; // Adjust import path as needed

const HomePage: React.FC = () => {
  const [passwords, setPasswords] = useState([]);
  const navigate = useNavigate();
  const { token, logout } = useAuth(); // Use the custom hook to get auth token

  useEffect(() => {
    const fetchPasswords = async () => {
      try {
        if (token) {
          const response = await axios.get("http://localhost:8080/api/passwords", {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
          setPasswords(response.data);
        } else {
          // Redirect to login if no token
          navigate("/login");
        }
      } catch (error) {
        console.error("Error fetching passwords", error);
      }
    };

    fetchPasswords();
  }, [token, navigate]);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="home-container">
      <header className="home-header">
        <div className="profile-container">
          <img src="/path-to-profile-pic.jpg" alt="Profile" className="profile-pic" />
          <button onClick={handleLogout} className="logout-button">Logout</button>
        </div>
        <div className="nav-links">
          <Link to="/add-password" className="add-password-link">Add Password</Link>
        </div>
      </header>

      <main className="password-list-container">
        <h2>Your Saved Passwords</h2>
        {passwords.length > 0 ? (
          <ul className="password-list">
            {passwords.map((password) => (
              <li key={password.id} className="password-item">
                <strong>{password.serviceName}</strong>: {password.password}
              </li>
            ))}
          </ul>
        ) : (
          <p>No passwords saved yet.</p>
        )}
      </main>
    </div>
  );
};

export default HomePage;
